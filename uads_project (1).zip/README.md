Universal Anomaly Detection System (UADS) - Quick Start

Files included:
- backend/: FastAPI backend
- frontend/: Streamlit frontend
- models/: model storage (created at runtime)
- outputs/: saved reports (created at runtime)
- requirements.txt, Dockerfile, README.md

Quick start (local):
1. python -m venv .venv && source .venv/bin/activate
2. pip install -r requirements.txt
3. uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
4. streamlit run frontend/app_streamlit.py

Notes:
- pytesseract may require system tesseract installed (apt-get install -y tesseract-ocr).
- This is a baseline lightweight system using IsolationForest.
