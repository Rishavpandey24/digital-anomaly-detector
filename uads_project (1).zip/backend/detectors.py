from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from PIL import Image
import joblib
from model_store import ModelStore
from utils import detect_mime_type, extract_text_from_doc

class BaseDetector:
    def __init__(self, name, store: ModelStore):
        self.name = name
        self.store = store
        self.model = None
        self.scaler = None
        self.model_key = f"detector_{self.name}"
        loaded = store.load(self.model_key)
        if loaded:
            try:
                self.model, self.scaler = loaded
            except Exception:
                self.model = None
                self.scaler = None

    def save(self):
        if self.model is not None:
            self.store.save(self.model_key, (self.model, self.scaler))

    def fit(self, X, contamination=0.01):
        self.scaler = StandardScaler()
        Xs = self.scaler.fit_transform(X)
        self.model = IsolationForest(contamination=contamination, random_state=42)
        self.model.fit(Xs)
        self.save()

    def score(self, X):
        if self.model is None or self.scaler is None:
            self.fit(X)
        Xs = self.scaler.transform(X)
        scores = -self.model.decision_function(Xs)
        return scores

    def explain(self, X):
        scores = self.score(X)
        thresh = np.percentile(scores, 100.0 - 1.0) if len(scores) > 1 else scores.max()
        return {'scores': scores.tolist(), 'is_anomaly': (scores > thresh).astype(int).tolist()}

class ImageDetector(BaseDetector):
    def __init__(self, store):
        super().__init__('image', store)

    def _extract_features(self, path):
        im = Image.open(path).convert('L')
        im = im.resize((64,64))
        arr = np.array(im).astype(float) / 255.0
        feat1 = np.histogram(arr.ravel(), bins=32, range=(0,1))[0].astype(float)
        feat2 = arr.ravel()[::8]
        feat = np.concatenate([feat1 / (feat1.sum()+1e-9), feat2])
        return feat

    def handle_file(self, path):
        f = Path(path)
        feat = self._extract_features(str(f))
        res = self.explain(feat.reshape(1,-1))
        return {'type': 'image', 'filename': f.name, 'result': res}

class TextDetector(BaseDetector):
    def __init__(self, store):
        super().__init__('text', store)

    def _extract_features_from_text(self, text):
        import re
        toks = re.findall(r"\w+", text.lower())
        from collections import Counter
        c = Counter(toks)
        common = [w for w,_ in c.most_common(50)]
        vec = np.array([c.get(w,0) for w in common], dtype=float)
        if vec.sum() == 0:
            vec = vec + 1e-6
        return vec

    def handle_file(self, path):
        text = extract_text_from_doc(path)
        feat = self._extract_features_from_text(text)
        res = self.explain(feat.reshape(1,-1))
        return {'type': 'text', 'filename': Path(path).name, 'result': res}

class SensorDetector(BaseDetector):
    def __init__(self, store):
        super().__init__('sensor', store)

    def handle_dataframe(self, df: pd.DataFrame):
        num = df.select_dtypes(include=[np.number]).fillna(method='ffill').fillna(0.0)
        if num.shape[1] == 0:
            raise ValueError('No numeric columns in sensor data')
        window = 5
        features = []
        arr = num.values
        for i in range(len(arr)):
            start = max(0, i-window+1)
            w = arr[start:i+1]
            stats = np.concatenate([w.mean(axis=0), w.std(axis=0)])
            feat = np.concatenate([arr[i], stats])
            features.append(feat)
        X = np.vstack(features)
        scores = self.score(X)
        return {'type': 'sensor', 'n_rows': len(X), 'scores': scores.tolist(), 'is_anomaly': (scores > np.percentile(scores, 99)).astype(int).tolist()}

class VideoDetector(BaseDetector):
    def __init__(self, store):
        super().__init__('video', store)

    def handle_file(self, path):
        from utils import extract_frames
        frames = extract_frames(path, max_frames=50, step=10)
        imgdet = ImageDetector(self.store)
        feats = []
        for f in frames:
            feats.append(imgdet._extract_features(f))
        X = np.vstack(feats) if len(feats)>0 else np.zeros((0,1))
        if X.shape[0] == 0:
            return {'type': 'video', 'n_frames': 0, 'scores': [], 'is_anomaly': []}
        scores = self.score(X)
        return {'type': 'video', 'n_frames': X.shape[0], 'scores': scores.tolist(), 'is_anomaly': (scores > np.percentile(scores, 99)).astype(int).tolist()}

class DetectorRouter:
    def __init__(self, store: ModelStore):
        self.store = store
        self.image = ImageDetector(store)
        self.text = TextDetector(store)
        self.sensor = SensorDetector(store)
        self.video = VideoDetector(store)

    def handle_file(self, path, contamination=0.01):
        mime = detect_mime_type(path)
        if mime.startswith('image'):
            return self.image.handle_file(path)
        if mime.startswith('video'):
            return self.video.handle_file(path)
        if mime in ('text', 'pdf', 'docx'):
            return self.text.handle_file(path)
        if path.lower().endswith('.csv'):
            import pandas as pd
            df = pd.read_csv(path)
            return self.sensor.handle_dataframe(df)
        raise ValueError('Unsupported file type: ' + mime)

    def handle_sensor_dataframe(self, df, contamination=0.01):
        return self.sensor.handle_dataframe(df)
