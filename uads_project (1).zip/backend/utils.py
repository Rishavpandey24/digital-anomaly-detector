import mimetypes
from pathlib import Path
import pdfplumber
from docx import Document

mimetypes.init()

def detect_mime_type(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext in ('.png', '.jpg', '.jpeg', '.bmp', '.tiff'):
        return 'image'
    if ext in ('.mp4', '.mov', '.avi', '.mkv'):
        return 'video'
    if ext in ('.txt', '.csv'):
        return 'text'
    if ext == '.pdf':
        return 'pdf'
    if ext in ('.doc', '.docx'):
        return 'docx'
    mt, _ = mimetypes.guess_type(str(p))
    if mt:
        return mt.split('/')[0]
    return 'unknown'

def extract_text_from_doc(path):
    p = Path(path)
    ext = p.suffix.lower()
    if ext == '.txt' or ext == '.csv':
        try:
            return p.read_text(errors='ignore')
        except Exception:
            return ''
    if ext == '.pdf':
        try:
            text = []
            with pdfplumber.open(path) as pdf:
                for page in pdf.pages:
                    text.append(page.extract_text() or '')
            return '\n'.join(text)
        except Exception:
            return ''
    if ext in ('.doc', '.docx'):
        try:
            doc = Document(path)
            return '\n'.join([p.text for p in doc.paragraphs])
        except Exception:
            return ''
    return ''

def extract_frames(video_path, max_frames=50, step=5):
    import cv2
    from pathlib import Path
    p = Path(video_path)
    cap = cv2.VideoCapture(str(p))
    frames = []
    idx = 0
    saved = []
    tmpdir = Path('/tmp/uads_frames')
    tmpdir.mkdir(parents=True, exist_ok=True)
    while len(saved) < max_frames:
        ret, frame = cap.read()
        if not ret:
            break
        if idx % step == 0:
            tmp = tmpdir / f'uads_frame_{idx}.png'
            cv2.imwrite(str(tmp), frame)
            saved.append(str(tmp))
        idx += 1
    cap.release()
    return saved
