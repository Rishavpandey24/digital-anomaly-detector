from pathlib import Path
import joblib

class ModelStore:
    def __init__(self, base_dir):
        self.base = Path(base_dir)
        self.base.mkdir(parents=True, exist_ok=True)

    def _path(self, key):
        return self.base / f"{key}.joblib"

    def save(self, key, obj):
        joblib.dump(obj, str(self._path(key)))

    def load(self, key):
        p = self._path(key)
        if p.exists():
            try:
                return joblib.load(str(p))
            except Exception:
                return None
        return None

    def list_models(self):
        return [p.stem for p in self.base.glob('*.joblib')]

    def retrain_model(self, key):
        print('Retrain requested for', key)
        return True
