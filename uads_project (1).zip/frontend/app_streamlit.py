import streamlit as st
import requests
import pandas as pd
import io

API = st.sidebar.text_input('Backend API URL', value='http://localhost:8000')

st.title('Universal Anomaly Detection System (UADS)')
st.write('Upload images, video, documents, or paste sensor CSV. The backend will auto-detect and analyze anomalies.')

mode = st.radio('Input mode', ['Upload file(s)', 'Paste sensor CSV (stream)', 'Live camera (local)'])

if mode == 'Upload file(s)':
    uploaded = st.file_uploader('Choose file(s)', accept_multiple_files=True)
    contamination = st.sidebar.slider('Contamination (expected anomaly fraction)', 0.0, 0.2, 0.01, 0.001)
    if uploaded:
        for f in uploaded:
            files = {'file': (f.name, f.getvalue())}
            with st.spinner(f'Uploading {f.name}...'):
                try:
                    resp = requests.post(API + '/upload', files=files, data={'contamination': contamination})
                    if resp.ok:
                        st.success(f'Processed {f.name}')
                        res = resp.json().get('result')
                        st.write(res)
                    else:
                        st.error('Processing failed: ' + resp.text)
                except Exception as e:
                    st.error('Request error: ' + str(e))

elif mode == 'Paste sensor CSV (stream)':
    txt = st.text_area('Paste CSV rows here (first line = header)')
    contamination = st.sidebar.slider('Contamination', 0.0, 0.2, 0.01, 0.001)
    if st.button('Analyze CSV') and len(txt) > 10:
        try:
            resp = requests.post(API + '/stream_sensor', data={'rows': txt, 'contamination': contamination})
            if resp.ok:
                st.success('Sensor data analyzed')
                st.json(resp.json()['result'])
            else:
                st.error('Error: ' + resp.text)
        except Exception as e:
            st.error('Request error: ' + str(e))

else:
    st.info('Local camera streaming not implemented in this minimal UI. Use the upload or sensor CSV mode.')

st.sidebar.markdown('---')
if st.sidebar.button('List backend models'):
    try:
        r = requests.get(API + '/models')
        st.sidebar.write(r.json())
    except Exception as e:
        st.sidebar.error(str(e))
